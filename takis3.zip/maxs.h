void solve(int**array,int i,int j);
