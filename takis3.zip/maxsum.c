#include <stdio.h>
#include <stdlib.h>

#include "maxs.h"

void print_array(int **,int,int);
int main(void){
  int **array;
  int i,j,k,l;
  printf("Give array size (i,j) ");
  scanf("%d",&i);
  scanf("%d",&j);
  //malloc
  array=(int **)malloc(i*sizeof(int*));
  if(array==NULL){
    return 1;
  }
  for(k=0;k<i;k++){
    array[k]=(int *)malloc(j*sizeof(int));
    if(array[k]==NULL){
      return 1;
    }
  }

  printf("Enter data: ");
  for(l=0;l<i;l++){
    for(k=0;k<j;k++){
      scanf("%d",&array[l][k]);

    }
  }
  print_array(array,i,j);
  solve(array,i-1,j-1);//dino -1 gia na pairnei sosta max gt allios tha evgaze segme kai kano loop mexri <=

}

void print_array(int **array,int i,int j){
  int k,l;
  printf("Printing array\n");
  for(k=0;k<i;k++){
    for (l=0;l<j;l++){
      printf("%d ",array[k][l]);
    }
    printf("\n");
  }

}
