//Recursive
#include<stdio.h>
#include<stdlib.h>

#include"maxs.h"

int max(int a,int b,int c){
  if (a>=b&&a>=c){
    return a;
  }
  else if(b>=a&&b>=c){
    return b;
  }
  else
    return c;
  }

 int s(int **array,int i,int j,int m){
   if (i==0)//vazo == 0 gia na paeii stin proti thesi tou pinaka
    return array[i][j];
  else if(i>0&&j==0)
    return (array[i][0]+max(s(array,i-1,m,m),s(array,i-1,0,m),s(array,i-1,1,m)));
  else  if(i>0&&j>0&&j<m)
    return(array[i][j]+max(s(array,i-1,j-1,m),s(array,i-1,j,m),s(array,i-1,j+1,m)));
  else
    return(array[i][m]+max(s(array,i-1,m-1,m),s(array,i-1,m,m),s(array,i-1,0,m)));
  }
  



 void solve(int **array,int i,int j){
   int l,maxsum=0,sum;
     for(l=0;l<=j;l++){
       sum=s(array,i,l,j);
         if (sum>maxsum)
            maxsum=sum;

     }


   printf("Max distance is %d",maxsum);
 }
