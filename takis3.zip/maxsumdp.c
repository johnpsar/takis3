//dynamic programming
#include<stdio.h>
#include<stdlib.h>

#include"maxs.h"
void maxPath(int**,int,int);
int dparray[1000][1000];
int max(int a,int b,int c){
  if (a>=b&&a>=c){
    return a;
  }
  else if(b>=a&&b>=c){
    return b;
  }
  else
    return c;
  }

 int s(int **array,int i,int j,int m){
   if (i==0)//vazo == 0 gia na paeii stin proti thesi tou pinaka
    return array[i][j];
  else if(i>0&&j==0)
    if(dparray[i][0]!=-1){
      return(dparray[i][0]);
      }
      else{
        dparray[i][0]=(array[i][0]+max(s(array,i-1,m,m),s(array,i-1,0,m),s(array,i-1,1,m)));
        return (dparray[i][0]);
  }
  else  if(i>0&&j>0&&j<m){
    if(dparray[i][j]!=-1){
      return dparray[i][j];
    }
    else{
    dparray[i][j]=(array[i][j]+max(s(array,i-1,j-1,m),s(array,i-1,j,m),s(array,i-1,j+1,m)));
    return dparray[i][j];
    }
  }
  else{
    if(dparray[i][m]!=-1){
      return dparray[i][m];
    }
    else{
    dparray[i][m]=(array[i][m]+max(s(array,i-1,m-1,m),s(array,i-1,m,m),s(array,i-1,0,m)));
    return dparray[i][m];
  }
  }

}


 void solve(int **array,int i,int j){
   int l,k,maxsum=0,sum;

   for(l=0;l<1000;l++){
     for(k=0;k<1000;k++){
       dparray[l][k]=-1;
     }
   }

   for (k=0;k<=i;k++){
     for(l=0;l<=j;l++){

          sum=s(array,i,l,j);
         if (sum>maxsum)
            maxsum=sum;

     }
}
   printf("Max distance is %d \n",maxsum);
   #ifdef PATH
   maxPath(array,i,j);
   #endif
 }

 void maxPath(int **array,int i,int j){
   int k,l,maxnum=-1,maxj;
   //find first element
   for(l=0;l<=j;l++){
     if(array[0][l]>maxnum){
       maxnum=array[0][l];
     }
   }
   printf("%d ->",maxnum);
   for(k=1;k<=i;k++){
     maxnum=-1;
     maxj=-1;
     for(l=0;l<=j;l++){
       if(dparray[k][l]>maxnum){
         maxnum=dparray[k][l];
         maxj=l;
       }
     }
     printf("%d ->",array[k][maxj] );
 }
}
